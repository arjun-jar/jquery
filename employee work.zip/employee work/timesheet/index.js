const date = document.querySelector(".date");
const left = document.querySelector(".left-arrow")
const right = document.querySelector(".right-arrow")
const daysDiv = document.querySelector(".right-nav_slot")
const numberSlot = document.querySelector(".number-slot")
const numberSlots = document.querySelector(".number-slots")
const totoalTime = document.querySelector(".total-time")
const add = document.querySelector(".add-btn")
var $edits=document.querySelectorAll('.edit')


var totalDays;
window.onload = function (array) {
  const todayDate = new Date().toISOString()
  const year = todayDate.slice(0, 4);
  const month = todayDate.slice(5, 7);
  date.value= todayDate.slice(0,10)
  let dates = getDaysInMonth(month - 1, +year);
  totalDays=dates.length
  createFunc(dates);
  addEventtoEdit( $edits)
}


left.addEventListener("click", previousMonth)
right.addEventListener("click",nextMonth)

function previousMonth() {
  let nextDate = new Date(new Date(date.value).getFullYear(), new Date(date.value).getMonth())
  nextDate = nextDate.toISOString().slice(0, 10)
  date.value = nextDate
  let dates = getDaysInMonth(+nextDate.slice(5, 7) - 1, +nextDate.slice(0, 4));
  totalDays=dates.length
  createFunc(dates);
  counter =1;
  $(".table").find($("tr")).slice(3).remove()
}

function nextMonth() { 
    let nextDate = new Date(new Date(date.value).getFullYear(), new Date(date.value).getMonth()+2)
    nextDate = nextDate.toISOString().slice(0, 10)
    date.value = nextDate
    let dates = getDaysInMonth(+nextDate.slice(5, 7) - 1, +nextDate.slice(0, 4));
    totalDays=dates.length
    createFunc(dates);
    counter =1;
    $(".table").find($("tr")).slice(3).remove()
}


function addDetails(array) {
  const newDiv = document.createElement("div");
  for (let i = 0; i < array.length; i++) {
    const dayDiv = document.createElement("div")
    dayDiv.classList.add("date-details")
    const timeDiv_1 = document.createElement("div")
    const tTime = document.createElement("input")
    dayDiv.innerHTML = `${array[i].toLocaleDateString("locale", { weekday: "short", })}<div class="day_month">${array[i].getDate()}${" "}${array[i].toLocaleString("default", { month: "short" })}</div>`
    tTime.classList.add(`time-box-${i+1}`)
    tTime.classList.add(`hours`)

    tTime.setAttribute("readonly", "true")
    daysDiv.appendChild(dayDiv)
    numberSlot.appendChild(timeDiv_1)
    totoalTime.appendChild(tTime)
  }
  addSlots()
  addSlots()
   
}


add.addEventListener('click',()=>{
  addSlots()
  addTableRow()
})
var counter =1;

function addSlots(){
  var slot=document.createElement('div')
  slot.classList.add('number-slot')
  slot.classList.add(`n_slot-${counter}`)
  for (let i = 0; i < totalDays; i++) {
    var numberSlot = document.createElement("div")
    numberSlot.innerHTML = `<input type="number" class=box-${i+1} />`
    numberSlot.classList.add(`number-slot-${counter}`)
    slot.appendChild(numberSlot)
  }
  numberSlots.appendChild(slot)
  counter++;
}


function addTableRow(){
  var row = $('<tr></tr>').attr({ class: ["delete",`slot-${counter-1}`, "class3"].join(' ') }).appendTo($('.table'));
  $('<td><input readonly="true"/></td>').appendTo(row);
  $('<td><input readonly="true"/></td>').appendTo(row);
  $('<td><input readonly="true"/></td>').appendTo(row);
  $('<td><input readonly="true"/></td>').appendTo(row);
  $('<td><input readonly="true"/></td>').appendTo(row);
  $('<td><button class="edit"><i class="fas fa-edit"></i></button><button  class="save"><i class="fas fa-save"></i></button><button class="trash"><i class="fas fa-trash"></i></button></td>').appendTo(row);
   $edits=document.querySelectorAll('.edit')
   $save=document.querySelectorAll('.save')
    addEventtoEdit($edits)
    addEventtoSave($save)
     deleteRow()
 

}
 document.querySelectorAll('.edit').forEach(edit=>{
  edit.addEventListener('click',(e)=>{
    for(let j=0;j<e.target.parentNode.parentNode.childNodes.length;j++){
      $(e.target.parentNode.parentNode.childNodes[j].childNodes[0]).addClass("active");
     $(e.target.parentNode.parentNode.childNodes[j].childNodes[0]).prop("readonly",false)
   }
  })
 })
 document.querySelectorAll('.save').forEach(save=>{
  save.addEventListener('click',(e)=>{
    $(e.target.parentNode.previousElementSibling).show()
    $(e.target.parentNode).hide()
 for(let j=0;j<e.target.parentNode.parentNode.parentNode.childNodes.length-1;j++){

  $(e.target.parentNode.parentNode.parentNode.childNodes[j].childNodes[0]).prop('readonly', true)
 }
  })
 })
 

 document.querySelector('.clear').addEventListener('click',()=>{
  
  $(".table").find($("tr")).slice(1).remove()
  $(".number-slots").find($("div")).slice(1).remove()
   document.querySelectorAll('.hours').forEach(hour=>{
  hour.value=""
 })
 $('.total-hours').text('')
 })



function addEventtoEdit($edits){
  for(let i=0;i<$edits.length;i++){
   $edits[i].addEventListener('click',(e)=>{
    $(e.target).hide()
    $(e.target).next().show()
    for(let j=0;j<e.target.parentNode.parentNode.childNodes.length;j++){
       $(e.target.parentNode.parentNode.childNodes[j].childNodes[0]).addClass("active");
      $(e.target.parentNode.parentNode.childNodes[j].childNodes[0]).prop("readonly",false)
    }
   })
  }

}
function addEventtoSave($save){
  for(let i=0;i<$save.length;i++){
   $save[i].addEventListener('click',(e)=>{
    $(e.target.parentNode.previousElementSibling).show()
    $(e.target.parentNode).hide()
 for(let j=0;j<e.target.parentNode.parentNode.parentNode.childNodes.length-1;j++){

  $(e.target.parentNode.parentNode.parentNode.childNodes[j].childNodes[0]).prop('readonly', true)
 }
     
   })
  }
}
 
function deleteRow(){
  var $trash=document.querySelectorAll('.trash')
  for(let i=0;i<$trash.length;i++){
    $trash[i].addEventListener('click',(e)=>{
      var td = e.target.parentNode; 
      if(td.parentNode.parentNode.classList.contains('delete')){
        var deleteItems=td.parentNode.parentNode.classList[1]
   
      document.querySelector(`.n_${deleteItems}`).remove();
        
        td.parentNode.parentNode.remove(); // the row to be removed

      }

   })
   }
}

function createFunc(array) {
  daysDiv.innerHTML = "";
  totoalTime.innerHTML = "";
  numberSlots.innerHTML = "";
  addDetails(array)
}
date.addEventListener("change", (e) => {
  const date = e.target.value;
  const year = date.slice(0, 4);
  const month = date.slice(5, 7);
  let array = getDaysInMonth(month - 1, +year);
  createFunc(array);
});

function getDaysInMonth(month, year) {
  var date = new Date(year, month, 1);
  var days = [];
  while (date.getMonth() === month) {
    days.push(new Date(date));
    date.setDate(date.getDate() + 1);
  }
  return days;
}
 
document.addEventListener("change", (e) => {



var targetClass=`time-${e.target.className}`
var $total= $(document.querySelector(`.${targetClass}`))
var  slots=document.querySelectorAll(`.${e.target.className}`)
 var totalValue=0;
for(let i=0;i<slots.length;i++){
  var total=Number($(slots[i]).val())
   totalValue+=total
  }
  $total[0].value=totalValue
  totalHoursFuntion()
})

 
function totalHoursFuntion(){
  var totalHours=0;
 var totalTime=document.querySelectorAll('.hours').forEach(hour=>{
  totalHours+=Number(hour.value)
 })
 $('.total-hours').text(totalHours)
}
